﻿#ifndef SHOOTARG_H
#define SHOOTARG_H

#include <QWidget>
#include <QPushButton>
#include <QSpinBox>
#include <QDoubleSpinBox>
#include <QString>
#include <QGroupBox>
#include <QGridLayout>
#include <QHBoxLayout>
#include <QFile>
#include <QSettings>

class shootArg : public QWidget
{
    Q_OBJECT
private:
    QGroupBox *ArgGroupBox;
    QSpinBox  *Motor1SpinBox;
    QSpinBox  *Motor2SpinBox;
    QDoubleSpinBox *AngleSpinBox;
    QDoubleSpinBox *VangleSpinBox;
    QPushButton  *changeBtn;
    QPushButton  *sendBtn;
    bool CSflag=true;
    void initdata(const QString &fname);
    void creatAll();
    QString createtemp;
    QString formatdata(int motor1,int motor2,double angle);
public:
    explicit shootArg(const QString &groupname, QWidget *parent = Q_NULLPTR);
    ~shootArg();
    QString Argdata();
    QString getAngle();
    int getAngleint();

signals:
    void needdata(QString data);
public slots:
    void senddata();
    void disablesendBtn(bool Issend);
    void AoSM1(bool IsA);
    void AoSM2(bool IsA);
    void AoSAn(bool IsA);
    void AoSVA(bool IsA);
     void chgOsv();
};

#endif // SHOOTARG_H
