﻿#ifndef TCPSERIAL_H
#define TCPSERIAL_H
#include <QMessageBox>
#include <QWidget>
#include <QPushButton>
#include <QComboBox>
#include <QGridLayout>
#include <QString>
#include <QTextEdit>
#include <QLineEdit>
#include <QCheckBox>
#include <QDebug>
// JasonQt lib import
#include "QThreadserial/JasonQt_SerialPort.h"

#include <QWidget>

class tcpserial : public QWidget
{
    Q_OBJECT
private:
    QPushButton *pushButton_open;
    QPushButton *pushButton_close;
    QPushButton *pushButton_refresh;
    QComboBox   *comboBox_availablePorts;
    QTextEdit   *sendEdit;
    QTextEdit   *acceptEdit;
    QLineEdit  *senddataEdit;
    QCheckBox  *hexCheck;
    QPushButton *sendBtn;

     char ConvertHexChar(char ch);
     JasonQt_SerialPort m_serialPort;
     ~tcpserial();
public:
    explicit tcpserial(QWidget *parent = 0);
    QString currentserial();
    QByteArray QString2Hex(QString str);
    void setCurrentSerial(QString COMNAME);
   // bool testtcp = false;


signals:
    void opened(bool);
    void closed();
    void RisOk();
    void RisOn(bool Issend);
    void RisOff();
    void showdata(QString);
    void control_WE(QString controldata);//发送控制数据



public slots:
     void refresh(void);

     void open(void);

     void close(void);

     void send(QString data);

     void QStringsend(QString data);

     void accepted(QByteArray data);

     void error(const QSerialPort::SerialPortError &error);
};

#endif // MYTHREADSERIAL_H
