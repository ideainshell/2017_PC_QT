﻿#ifndef MYTHREADSERIAL_H
#define MYTHREADSERIAL_H

/*
 *
 * QT += serialport
 *  CONFIG += c++11
 *
*/
// Qt lib import
#include <QMessageBox>
#include <QWidget>
#include <QPushButton>
#include <QComboBox>
#include <QGridLayout>
#include <QString>
#include <QTextEdit>
#include <QLineEdit>
#include <QCheckBox>
#include <QDebug>
#include <QPlainTextEdit>
// JasonQt lib import
#include "QThreadserial/JasonQt_SerialPort.h"

#include <QWidget>

class myThreadSerial : public QWidget
{
    Q_OBJECT
private:
    QPushButton *pushButton_open;
    QPushButton *pushButton_close;
    QPushButton *pushButton_refresh;
    QComboBox   *comboBox_availablePorts;
    QTextEdit   *sendEdit;
    QPlainTextEdit   *acceptEdit;

    QPushButton *sendclearBtn;
    QPushButton *acepclearBtn;

    QLineEdit  *senddataEdit;
    QCheckBox  *hexCheck;
    QPushButton *sendBtn;

     char ConvertHexChar(char ch);
     JasonQt_SerialPort m_serialPort;
     ~myThreadSerial();
public:
    explicit myThreadSerial(QWidget *parent = 0);
    QString currentserial();
    QByteArray QString2Hex(QString str);
    void setCurrentSerial(QString COMNAME);
    QGridLayout *ComLayout ;
    QGridLayout *ShowLayout ;

signals:
    void opened(bool);
    void closed();
    void RisOk(bool okflag);
    void RisOn(bool Issend);
    void RisOff();
    void showdata(QString);
    void showdataout(QString);
public slots:
     void refresh(void);

     void open(void);

     void close(void);

     void QCharsend(QByteArray data);

     void send(QString data);

     void QStringsend(QString data);

     void accepted(QByteArray data);

     void error(const QSerialPort::SerialPortError &error);

     void on_checkBox_stateChanged(int arg1);

     void on_senddata_clicked();

     void send_clear();

     void acep_clear();
};

#endif // MYTHREADSERIAL_H
