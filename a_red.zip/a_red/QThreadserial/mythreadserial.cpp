﻿#include "QThreadserial/mythreadserial.h"

myThreadSerial::myThreadSerial(QWidget *parent) : QWidget(parent)
{
    pushButton_refresh = new QPushButton;      //串口刷新按钮，连接刷新按钮槽
    pushButton_refresh->setFixedSize(241,46);
    pushButton_refresh->setText(QString::fromLocal8Bit("刷新串口"));
    connect(pushButton_refresh, SIGNAL(clicked()), this, SLOT(refresh()));

    pushButton_open = new QPushButton;        //串口打开按钮，连接开启按钮槽
    pushButton_open->setFixedSize(241,46);
    pushButton_open->setText(QString::fromLocal8Bit("打开串口"));
    connect(pushButton_open,    SIGNAL(clicked()), this, SLOT(open()));

    pushButton_close = new QPushButton;       //串口关闭按钮，连接关闭按钮槽
    pushButton_close->setFixedSize(241,46);
    pushButton_close->setText(QString::fromLocal8Bit("关闭串口"));
    connect(pushButton_close,   SIGNAL(clicked()), this, SLOT(close()));

    sendclearBtn = new QPushButton;           //串口发送框清空按钮，连接清口发送框按钮槽
    sendclearBtn->setFixedSize(241,46);
    sendclearBtn->setText(QString::fromLocal8Bit("清发送"));
    connect(sendclearBtn,   SIGNAL(clicked()), this, SLOT(send_clear()));

    acepclearBtn = new QPushButton;           //串口接受框清空按钮，连接清空接收框按钮槽
    acepclearBtn->setFixedSize(241,46);
    acepclearBtn->setText(QString::fromLocal8Bit("清接收"));
    connect(acepclearBtn,   SIGNAL(clicked()), this, SLOT(acep_clear()));

    comboBox_availablePorts = new QComboBox;  //串口号读取，下拉框
    comboBox_availablePorts->setFixedSize(241,46);
    comboBox_availablePorts->setStyleSheet("font-size : 27px");

    sendEdit = new QTextEdit;              //发送内容显示框
    sendEdit->setFixedSize(381,206);
    acceptEdit = new QPlainTextEdit;            //接受内容显示框
    acceptEdit->setFixedSize(381,206);

    senddataEdit = new QLineEdit;          //手动发送框
    senddataEdit->setFixedSize(381,31);

    hexCheck = new QCheckBox;              //16进制发送勾选，连接切换发送格式槽
    hexCheck->setFixedSize(161,31);
    hexCheck->setText(QString::fromLocal8Bit("十六进制输入"));
    connect(hexCheck,SIGNAL(stateChanged(int)),this,SLOT(on_checkBox_stateChanged(int)));

    sendBtn = new QPushButton;            //手动数据发送按钮，连接到手动按钮发送槽
    sendBtn->setFixedSize(161,31);
    sendBtn->setText(QString::fromLocal8Bit("发送"));
    connect(sendBtn,SIGNAL(clicked(bool)),this,SLOT(on_senddata_clicked()));

    ComLayout =new QGridLayout;
    ComLayout->addWidget(comboBox_availablePorts,0,0);
    ComLayout->addWidget(pushButton_refresh,0,1);
    ComLayout->addWidget(sendclearBtn,0,2);
    ComLayout->addWidget(pushButton_open,1,0);
    ComLayout->addWidget(pushButton_close,1,1);
    ComLayout->addWidget(acepclearBtn,1,2);


    ShowLayout =new QGridLayout;
    ShowLayout->addWidget(sendEdit,1,0);
    ShowLayout->addWidget(acceptEdit,2,0);
    ShowLayout->addWidget(senddataEdit,3,0);
    ShowLayout->addWidget(hexCheck,4,0);
    ShowLayout->addWidget(sendBtn,4,1);


    // 槽函数在主线程运行
    connect(&m_serialPort,  SIGNAL(accepted(QByteArray)), this, SLOT(accepted(QByteArray)));
    connect(&m_serialPort,  SIGNAL(error(QSerialPort::SerialPortError)), this, SLOT(error(QSerialPort::SerialPortError)));
    connect(this,SIGNAL(showdata(QString)),acceptEdit,SLOT(insertPlainText(QString)));
    // 槽函数在串口工作线程运行（在本示例中不推荐使用这个，因为要操作GUI）
//    connect(&m_serialPort,  SIGNAL(accepted(QByteArray)), this, SLOT(accepted(QByteArray)), Qt::DirectConnection);
//    connect(&m_serialPort,  SIGNAL(error(QSerialPort::SerialPortError)), this, SLOT(error(QSerialPort::SerialPortError)), Qt::DirectConnection);


    this->refresh();
}
myThreadSerial::~myThreadSerial()
{
}
void myThreadSerial::refresh(void)
{
    comboBox_availablePorts->clear();
    for(const auto &now: QSerialPortInfo::availablePorts())
    {
        comboBox_availablePorts->addItem(now.portName());
    }
    pushButton_open->setEnabled(comboBox_availablePorts->count());
}
void myThreadSerial::setCurrentSerial(QString COMNAME)
{
    for(int i=0;i<comboBox_availablePorts->count();i++)
      if(COMNAME==comboBox_availablePorts->itemText(i))
      {
          comboBox_availablePorts->setCurrentIndex(i);
      }
}

void myThreadSerial::open(void)
{
    if(m_serialPort.open(comboBox_availablePorts->currentText()))
    {
        pushButton_open->setEnabled(false);
        pushButton_close->setEnabled(true);
        pushButton_refresh->setEnabled(false);
        comboBox_availablePorts->setEnabled(false);
        emit opened(true);
    }
    else
    {
      //  QMessageBox::warning(this, "Open error", "Can open this serial port");
        emit opened(false);
    }
}

void myThreadSerial::close(void)
{
    m_serialPort.close();

    pushButton_open->setEnabled(true);
    pushButton_close->setEnabled(false);
    pushButton_refresh->setEnabled(true);
    comboBox_availablePorts->setEnabled(true);

    emit closed();
}
void myThreadSerial::QCharsend(QByteArray data)
{
    sendEdit->append(data.toHex().toUpper());
    m_serialPort.send(data);
}

void myThreadSerial::send(QString data)
{
    sendEdit->append(data);
    m_serialPort.send(QString2Hex(data));
}
void myThreadSerial::QStringsend(QString data)
{
    sendEdit->append(data);
    m_serialPort.send(data.toLatin1());
}

//   16进制转换函数
QByteArray myThreadSerial::QString2Hex(QString str)
{
        QByteArray senddata;
        int hexdata,lowhexdata;
        int hexdatalen = 0;
        int len = str.length();
        senddata.resize(len/2);
        char lstr,hstr;
        for(int i=0; i<len; )
        {
            hstr=str[i].toLatin1();
            if(hstr == ' ')
            {
                i++;
                continue;
            }
            i++;
            if(i >= len)
                break;
            lstr = str[i].toLatin1();
            hexdata = ConvertHexChar(hstr);
            lowhexdata = ConvertHexChar(lstr);
            if((hexdata == 16) || (lowhexdata == 16))
                break;
            else
                hexdata = hexdata*16+lowhexdata;
            i++;
            senddata[hexdatalen] = (char)hexdata;
            hexdatalen++;
        }
        senddata.resize(hexdatalen);
        return senddata;
}
//   字符转十六进制
char myThreadSerial::ConvertHexChar(char ch)
{
        if((ch >= '0') && (ch <= '9'))
            return ch-0x30;
        else if((ch >= 'A') && (ch <= 'F'))
            return ch-'A'+10;
        else if((ch >= 'a') && (ch <= 'f'))
            return ch-'a'+10;
        else return (-1);
}


void myThreadSerial::accepted(QByteArray data)
{
    //acceptEdit->append(data);
   // acceptEdit->insertPlainText(data);
    //emit showdata(QString(data));//通过槽发送显示的数据，效率会更高
    //qCritical()<<data;
    //acceptEdit->textCursor().insertText("\r\n");//这种方法~不知道为什么~不卡界面
    acceptEdit->textCursor().insertText(QString(data));
    acceptEdit->moveCursor(QTextCursor::End);

     static QByteArray allData;         //静态变量！！在串口只得到一部分的时候用来累加数据
     allData += data;                                //总数据加上本次数据
     static int allnum=0;
     allnum +=data.size();
     if(allnum>=20000)
     {
         allnum=0;
         acceptEdit->textCursor().insertText("\r\n");//这种方法~不知道为什么~不卡界面
     }
     if( data.contains('#'))
     {
          if(allData.contains("on#"))
          {
            allData.clear();
            emit RisOn(true);
          }
          if(allData.contains("of#"))
          {
            allData.clear();
            emit RisOff();
          }
          if(allData.contains("ok#"))
          {
            allData.clear();
             emit RisOk(true);
          }
     }

}

void myThreadSerial::error(const QSerialPort::SerialPortError &)
{
   // QMessageBox::warning(this, "Serial error", QString("Serial error: %1").arg(error));
}
QString myThreadSerial::currentserial()
{
    return comboBox_availablePorts->currentText();
}
void myThreadSerial::on_checkBox_stateChanged(int arg1)
{
    if(arg1==2)
      {
        senddataEdit->setInputMask("HH HH HH HH HH HH HH HH HH HH HH HH HH HH HH");
        senddataEdit->clear();
     }
    else
    {
         senddataEdit->setInputMask("");
    }

}
void myThreadSerial::on_senddata_clicked()
{

    QByteArray senddata;
    senddata=senddataEdit->text().toLatin1();
    if(hexCheck->isChecked()==false)
    {
        sendEdit->append(senddata);
        m_serialPort.send(senddata);

    }
     else
     {
        sendEdit->append(senddata.toUpper());
        senddata=QString2Hex(senddataEdit->text().toUpper());
        m_serialPort.send(senddata);
    }
}
void myThreadSerial::acep_clear()
{
    acceptEdit->clear();
}
void myThreadSerial::send_clear()
{
    sendEdit->clear();
}
