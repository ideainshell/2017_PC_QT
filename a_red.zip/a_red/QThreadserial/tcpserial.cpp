﻿#include "tcpserial.h"
#include <QDebug>
tcpserial::tcpserial(QWidget *parent) : QWidget(parent)
{
    pushButton_refresh = new QPushButton;
    pushButton_refresh->setFixedSize(141,46);
    pushButton_refresh->setText(QString::fromLocal8Bit("刷新串口"));
    connect(pushButton_refresh, SIGNAL(clicked()), this, SLOT(refresh()));

    pushButton_open = new QPushButton;
    pushButton_open->setFixedSize(141,46);
    pushButton_open->setText(QString::fromLocal8Bit("打开串口"));
    connect(pushButton_open,    SIGNAL(clicked()), this, SLOT(open()));

    pushButton_close = new QPushButton;
    pushButton_close->setFixedSize(141,46);
    pushButton_close->setText(QString::fromLocal8Bit("关闭串口"));
    connect(pushButton_close,   SIGNAL(clicked()), this, SLOT(close()));

    comboBox_availablePorts = new QComboBox;
    comboBox_availablePorts->setFixedSize(121,46);
    comboBox_availablePorts->setStyleSheet("font-size : 27px");

    acceptEdit = new QTextEdit;
    acceptEdit->setFixedSize(151,46);
    acceptEdit->setStyleSheet("font-size : 27px");

    QGridLayout *mainLayout =new QGridLayout(this);
    mainLayout->addWidget(comboBox_availablePorts,0,0);
    mainLayout->addWidget(pushButton_refresh,0,1);
    mainLayout->addWidget(pushButton_open,0,2);
    mainLayout->addWidget(pushButton_close,0,3);
    mainLayout->addWidget(acceptEdit,0,4);

    // 槽函数在主线程运行
    connect(&m_serialPort,  SIGNAL(accepted(QByteArray)), this, SLOT(accepted(QByteArray)));
    connect(&m_serialPort,  SIGNAL(error(QSerialPort::SerialPortError)), this, SLOT(error(QSerialPort::SerialPortError)));

    connect(this,SIGNAL(showdata(QString)),acceptEdit,SLOT(append(QString)));
    // 槽函数在串口工作线程运行（在本示例中不推荐使用这个，因为要操作GUI）
//    connect(&m_serialPort,  SIGNAL(accepted(QByteArray)), this, SLOT(accepted(QByteArray)), Qt::DirectConnection);
//    connect(&m_serialPort,  SIGNAL(error(QSerialPort::SerialPortError)), this, SLOT(error(QSerialPort::SerialPortError)), Qt::DirectConnection);


    this->refresh();
}
tcpserial::~tcpserial()
{
}

void tcpserial::refresh(void)
{
    comboBox_availablePorts->clear();
    for(const auto &now: QSerialPortInfo::availablePorts())
    {
        comboBox_availablePorts->addItem(now.portName());
    }
    pushButton_open->setEnabled(comboBox_availablePorts->count());
}
void tcpserial::setCurrentSerial(QString COMNAME)
{
    for(int i=0;i<comboBox_availablePorts->count();i++)
      if(COMNAME==comboBox_availablePorts->itemText(i))
      {
          comboBox_availablePorts->setCurrentIndex(i);
      }
}

void tcpserial::open(void)
{
    if(m_serialPort.open(comboBox_availablePorts->currentText()))
    {
        pushButton_open->setEnabled(false);
        pushButton_close->setEnabled(true);
        pushButton_refresh->setEnabled(false);
        comboBox_availablePorts->setEnabled(false);
        emit opened(true);
    }
    else
    {
      //  QMessageBox::warning(this, "Open error", "Can open this serial port");
        emit opened(false);
    }
}

void tcpserial::close(void)
{
    m_serialPort.close();

    pushButton_open->setEnabled(true);
    pushButton_close->setEnabled(false);
    pushButton_refresh->setEnabled(true);
    comboBox_availablePorts->setEnabled(true);

    emit closed();
}

void tcpserial::send(QString data)
{
    m_serialPort.send(QString2Hex(data));
}
void tcpserial::QStringsend(QString data)
{
    m_serialPort.send(data.toLatin1());
}

//   16进制转换函数
QByteArray tcpserial::QString2Hex(QString str)
{
        QByteArray senddata;
        int hexdata,lowhexdata;
        int hexdatalen = 0;
        int len = str.length();
        senddata.resize(len/2);
        char lstr,hstr;
        for(int i=0; i<len; )
        {
            hstr=str[i].toLatin1();
            if(hstr == ' ')
            {
                i++;
                continue;
            }
            i++;
            if(i >= len)
                break;
            lstr = str[i].toLatin1();
            hexdata = ConvertHexChar(hstr);
            lowhexdata = ConvertHexChar(lstr);
            if((hexdata == 16) || (lowhexdata == 16))
                break;
            else
                hexdata = hexdata*16+lowhexdata;
            i++;
            senddata[hexdatalen] = (char)hexdata;
            hexdatalen++;
        }
        senddata.resize(hexdatalen);
        return senddata;
}
//   字符转十六进制
char tcpserial::ConvertHexChar(char ch)
{
        if((ch >= '0') && (ch <= '9'))
            return ch-0x30;
        else if((ch >= 'A') && (ch <= 'F'))
            return ch-'A'+10;
        else if((ch >= 'a') && (ch <= 'f'))
            return ch-'a'+10;
        else return (-1);
}


void tcpserial::accepted(QByteArray data)
{
    //emit showdata(QString(data));
     acceptEdit->clear();
     static QByteArray allData;         //静态变量！！在串口只得到一部分的时候用来累加数据
     static bool getdata=false;

    /* if(!testtcp)
     {
         qCritical()<<data;
     }*/

     if(data.at(0)>='A'&&data.at(0)<='N')
     {

         emit showdata(QString(data));
         emit control_WE(QString(data));
         data.remove(0,data.indexOf('Q'));

     }
     if(getdata==false&&data.contains('Q'))
      {

       allData +=data;
       getdata=true;
     }
     else if(getdata==true)
      {
       allData +=data;
       if(allData.contains("\r\n"))
        {
           getdata=false;
           allData.remove(allData.size()-2,2);
           emit control_WE(QString(allData));
           emit showdata(QString(allData));
           allData.clear();
        }
     }
}

void tcpserial::error(const QSerialPort::SerialPortError &)
{
   // QMessageBox::warning(this, "Serial error", QString("Serial error: %1").arg(error));
}
QString tcpserial::currentserial()
{
    return comboBox_availablePorts->currentText();
}
