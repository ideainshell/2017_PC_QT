﻿#include "videocl.h"
#include "QTextStream"
#include <QDebug>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
videocl::videocl(QObject *parent)
                 : QThread(parent)
{
    intrinsics = cv::Mat(3,3,CV_32FC1);
    cv::FileStorage fs1("Distortion.xml", cv::FileStorage::READ);
    cv::FileStorage fs2("Intrinsics.xml", cv::FileStorage::READ);
    fs1["Distortion"]>>distortion;
    fs2["Intrinsics"]>>intrinsics;
}
videocl::~videocl()
{
}

bool videocl::stop = true;

void videocl::run()
{
    while (!stop)
    {
        cv::Mat image;
        cap>>srcframe;
        cv::Mat src;
        cv::undistort(srcframe,src,intrinsics,distortion);
        center=Detect(src,image);
        reFrame = Mat2QImage(image);
        Qcenter.setX(center.x);
        Qcenter.setY(center.y);
        emit ImageProcessFinished(reFrame,Qcenter);
        msleep(10);
    }
    this->exec();

}
//   图像转换
QImage videocl::Mat2QImage(cv::Mat cvImg)
{
    QImage qImg;
    if(cvImg.channels()==3)                             //3 channels color image
    {

        cv::cvtColor(cvImg,cvImg,cv::COLOR_BGR2RGB);
        qImg =QImage((const unsigned char*)(cvImg.data),
                    cvImg.cols, cvImg.rows,
                    cvImg.cols*cvImg.channels(),
                    QImage::Format_RGB888);
    }
    else if(cvImg.channels()==1)                    //grayscale image
    {
        qImg =QImage((const unsigned char*)(cvImg.data),
                    cvImg.cols,cvImg.rows,
                    cvImg.cols*cvImg.channels(),
                    QImage::Format_Indexed8);
    }
    else
    {
        qImg =QImage((const unsigned char*)(cvImg.data),
                    cvImg.cols,cvImg.rows,
                    cvImg.cols*cvImg.channels(),
                    QImage::Format_RGB888);
    }
    return qImg;

}
void videocl::openctrl(int capnum)
{
   cap.open(capnum);
   stop=false;
}
void videocl::closectrl()
{
    stop=true;
}
