﻿#ifndef VIDEOCL_H
#define VIDEOCL_H

#include <QObject>
#include <QWidget>
#include <QThread>
#include <opencv2\opencv.hpp>
#include "Detect.h"
#include <QPointF>
class videocl : public QThread
{
    Q_OBJECT
public:
    videocl(QObject *parent = 0);
    static bool stop;
    ~videocl();

private:
    void run();

    cv::Mat srcframe;
    cv::VideoCapture cap;
    QImage reFrame;
    cv::Point2f center;
    QPoint Qcenter;
    QImage Mat2QImage(cv::Mat cvImg);
    cv::Mat intrinsics;
    cv::Mat distortion;
signals:
    void ImageProcessFinished(QImage ,QPoint);

public slots:
    void openctrl(int capnum=0);
    void closectrl();

};

#endif // VIDEOCL_H
