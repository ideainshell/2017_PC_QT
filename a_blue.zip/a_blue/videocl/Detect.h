﻿#ifndef DETECT_H
#define DETECT_H

#include <opencv2\opencv.hpp>
#include <QObject>
#include <QWidget>
#define green Scalar(0,255,0)
#define red Scalar(0,0,255)
#define black Scalar(0,0,0)
cv::Point getCrossPoint(cv::Vec4i& a, cv::Vec4i& b);
cv::Vec4i getLongestLine(std::vector<cv::Vec4i>& lines);
void imageProcess(cv::Mat& src, cv::Mat& dst);
cv::Point Detect(cv::Mat& src,cv::Mat& imgToDraw);

#endif
