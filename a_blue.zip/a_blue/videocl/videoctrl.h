﻿#ifndef VIDEOCTRL_H
#define VIDEOCTRL_H

#include <QWidget>
#include <videocl/videocl.h>
#include <QPushButton>
#include <QComboBox>
#include <QGridLayout>
#include <QCameraInfo>
#include <QLabel>
#include <QSettings>
class videoctrl : public QWidget
{
    Q_OBJECT
private:
    QPushButton *openBtn;
    QComboBox *cameraCom;
    QLabel *scalelabel_t;
    QLabel *positionLabel;
    QLabel *positionLabel_t;
    bool camopened=false;
    void initcamerashow();
    QString QPointF2Data(QPoint &);
    videocl *thread;
    QPoint Qcenter2out;
public:
    explicit videoctrl(QWidget *parent = 0);
    ~videoctrl();
    QLabel *showlabel;
    QString getcenterdata();

signals:
    void getcenter(QString);
    void open(int);
    void close1();
    void opened(bool);
public slots:
    void opencamera();
    void ShowImageFromThread(QImage image,QPoint center);

};

#endif // VIDEOCTRL_H
