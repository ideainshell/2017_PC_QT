﻿#include "Detect.h"
using namespace cv;

void imageProcess(cv::Mat& src, cv::Mat& dst)
{
    dst = Mat::zeros(src.size(), CV_8U);
    std::vector<Mat>mc;
    std::vector<Mat>mt;
    Mat hsv, ycrcb;
    cvtColor(src, hsv, COLOR_BGR2HSV);
    cvtColor(src, ycrcb, COLOR_BGR2YCrCb);

    split(hsv, mc);
    split(ycrcb, mt);

    Mat sc = mc[1];
    Mat cb = mt[2];

    equalizeHist(sc, sc);
    equalizeHist(cb, cb);

    GaussianBlur(sc, sc, Size(3, 3), 1.1);
    GaussianBlur(cb, cb, Size(3, 3), 1.1);

    Mat dst1, dst2;

    adaptiveThreshold(sc, dst1, 255, ADAPTIVE_THRESH_GAUSSIAN_C, THRESH_BINARY_INV, 203, 12);//203 12
    adaptiveThreshold(cb, dst2, 255, ADAPTIVE_THRESH_GAUSSIAN_C, THRESH_BINARY_INV, 203, 12);

    Mat element = getStructuringElement(MORPH_ELLIPSE, Size(5, 5));
    Mat temp = dst1 & dst2;

    morphologyEx(temp,temp,MORPH_CLOSE,element);
    dilate(temp,temp,element);

    std::vector<std::vector<Point>>contours;
    findContours(temp, contours, RETR_EXTERNAL, CHAIN_APPROX_NONE);

    double maxContourSize = 0;
    int maxContourID = 0;
    for (size_t i = 0; i < contours.size(); i++)
    {
        double t = contourArea(contours[i]);
        if (t>maxContourSize)
        {
            maxContourSize = t;
            maxContourID = i;
        }
    }
    drawContours(dst, contours, maxContourID, 255);
}

cv::Point getCrossPoint(Vec4i& a, Vec4i& b)
{
    Point cross = Point(-1, -1);
    double x1, x2, x3, x4;
    double y1, y2, y3, y4;

    x1 = a[0];
    x2 = a[2];
    y1 = a[1];
    y2 = a[3];

    x3 = b[0];
    x4 = b[2];
    y3 = b[1];
    y4 = b[3];

    if ((x2 - x1) != 0 && (x4 - x3) != 0)
    {
        double k1 = (y2 - y1) / (x2 - x1);
        double b1 = (y1*x2 - y2*x1) / (x2 - x1);

        double k2 = (y4 - y3) / (x4 - x3);
        double b2 = (y3*x4 - y4*x3) / (x4 - x3);

        cross.x = cvRound((b1 - b2) / (k2 - k1));
        cross.y = cvRound((b1*k2 - b2*k1) / (k2 - k1));
    }
    else if ((x2 - x1) == 0 && (x4 - x3) != 0)
    {
        cross.x = (int)x2;

        double k2 = (y4 - y3) / (x4 - x3);
        double b2 = (y3*x4 - y4*x3) / (x4 - x3);

        cross.y = cvRound(k2*cross.x + b2);
    }
    else if ((x2 - x1) != 0 && (x4 - x3) == 0)
    {
        double k1 = (y2 - y1) / (x2 - x1);
        double b1 = (y1*x2 - y2*x1) / (x2 - x1);

        cross.x = (int)x4;

        cross.y = cvRound(k1*cross.x + b1);
    }
    else
    {
        return Point(0, 0);
    }
    return cross;
}
cv::Vec4i getLongestLine(std::vector<Vec4i>& lines)
{
    Vec4i l;
    size_t maxLen = 0, maxid = 0;
    for (size_t i = 0; i < lines.size(); i++)
    {
        int len = (abs(lines[i][0] - lines[i][2]) + abs(lines[i][1] - lines[i][3]));
        if (len>maxLen)
        {
            maxLen = len;
            maxid = i;
        }
    }
    return lines.at(maxid);
}


cv::Point Detect(Mat& src,Mat& imgToDraw)
{
    if (src.empty())
        return -1;
    resize(src, src, Size(320, 240));

    imgToDraw = src.clone();
    Mat dst;
    static Point center(src.cols/2,src.rows/2);
    static double scale = 1.5;

    static Point distance(0,0);
    Point ImgCenter(src.cols / 2, src.rows / 2);

    //图像处理
    imageProcess(src, dst);
    std::vector<Vec4i>lines;
    HoughLinesP(dst, lines, 1, CV_PI / 180, 45, 30, 80);

    Point cornors[4] = {Point(0,0)};
    std::vector<Vec4i> vertical;
    std::vector<Vec4i>horizon;
    for (size_t i = 0; i < lines.size(); i++)
    {
        int x1 = lines[i][0];
        int y1 = lines[i][1];
        int x2 = lines[i][2];
        int y2 = lines[i][3];
        if (abs(y2 - y1)>abs(x2 - x1))
            vertical.push_back(lines[i]);
        else
            horizon.push_back(lines[i]);
    }
    Vec4i hL = { 0, src.rows / 2, src.cols, src.rows / 2 };
    Vec4i vL= { src.cols / 2, 0, src.cols / 2, src.rows };

    Vec4i lf, rh, upl, bt;
    if (vertical.size() >= 2)//有竖线存在
    {
        std::vector<Vec4i>left, right;
        std::vector<double>h;
        double dis = 0;
        for (size_t i = 0; i < vertical.size(); i++)
        {
            double l1 = 0, l2 = 0, l = 0;
            int x1 = vertical[i][0];
            int y1 = vertical[i][1];
            int x2 = vertical[i][2];
            int y2 = vertical[i][3];
            l1 = sqrt(x1*x1 + y1*y1);
            l2 = sqrt(x2*x2 + y2*y2);
            l = sqrt((x2 - x1)*(x2 - x1) + (y2 - y1)*(y2 - y1));
            double p = (l1 + l2 + l) / 2;
            double S = sqrt(p*(p - l1)*(p - l2)*(p - l));
            double t = S / l;
            h.push_back(t);
            dis += t;
        }
        dis = dis / vertical.size();
        for (size_t i = 0; i < vertical.size(); i++)
        {
            if (h[i]>dis)
                right.push_back(vertical[i]);
            else
                left.push_back(vertical[i]);
        }
        if (left.size() != 0 && right.size()!=0)
        {
            lf = getLongestLine(left);
            rh = getLongestLine(right);

            line(imgToDraw, Point(lf[0], lf[1]), Point(lf[2], lf[3]), Scalar(255, 0, 0));
            line(imgToDraw, Point(rh[0], rh[1]), Point(rh[2], rh[3]), Scalar(255, 0, 0));
        }

    }

    if (horizon.size() >= 2)
    {
        std::vector<Vec4i>up, down;
        std::vector<double>h;
        double dis = 0;
        for (size_t i = 0; i < horizon.size(); i++)
        {
            double l1 = 0, l2 = 0, l = 0;
            int x1 = horizon[i][0];
            int y1 = horizon[i][1];
            int x2 = horizon[i][2];
            int y2 = horizon[i][3];
            l1 = sqrt(x1*x1 + y1*y1);
            l2 = sqrt(x2*x2 + y2*y2);
            l = sqrt((x2 - x1)*(x2 - x1) + (y2 - y1)*(y2 - y1));
            double p = (l1 + l2 + l) / 2;
            double S = sqrt(p*(p - l1)*(p - l2)*(p - l));
            double t = S / l;
            h.push_back(t);
            dis += t;
        }
        dis = dis / horizon.size();
        for (size_t i = 0; i < horizon.size(); i++)
        {
            if (h[i]>dis)
                down.push_back(horizon[i]);
            else
                up.push_back(horizon[i]);
        }

        if (up.size() != 0 && down.size()!=0)
        {
            upl = getLongestLine(up);
            bt = getLongestLine(down);
            line(imgToDraw, Point(upl[0], upl[1]), Point(upl[2], upl[3]), Scalar(255, 0, 0));
            line(imgToDraw, Point(bt[0], bt[1]), Point(bt[2], bt[3]), Scalar(255, 0, 0));
            center.y = (upl[1] + upl[3] + bt[1] + bt[3]) / 4;
        }
    }
    if (horizon.size() >= 2 && vertical.size() >= 2)
    {
        cornors[0] = getCrossPoint(lf, upl);
        cornors[1] = getCrossPoint(lf, bt);
        cornors[2] = getCrossPoint(rh, upl);
        cornors[3] = getCrossPoint(rh, bt);
        center.x = (cornors[0].x + cornors[1].x + cornors[2].x + cornors[3].x) / 4;
        center.y = (cornors[0].y + cornors[1].y + cornors[2].y + cornors[3].y) / 4;
        line(imgToDraw, cornors[1], cornors[3], Scalar(0, 128, 255));
        line(imgToDraw, cornors[0], cornors[2], Scalar(0, 128, 255));
    }
    else if (horizon.size() >= 2)
    {
        cornors[0] = getCrossPoint(upl, vL);
        cornors[1] = getCrossPoint(upl, vL);
        cornors[2] = getCrossPoint(bt, vL);
        cornors[3] = getCrossPoint(bt, vL);
        center.y = (cornors[0].y + cornors[1].y + cornors[2].y + cornors[3].y) / 4;
    }
    else if (vertical.size() >= 2)
    {
        cornors[0] = getCrossPoint(lf, hL);
        cornors[1] = getCrossPoint(lf, hL);
        cornors[2] = getCrossPoint(rh, hL);
        cornors[3] = getCrossPoint(rh, hL);
        center.x = (cornors[0].x + cornors[1].x + cornors[2].x + cornors[3].x) / 4;
        scale = 60.0 / (abs(cornors[0].x - cornors[1].x) + abs(cornors[0].x - cornors[2].x) + abs(cornors[0].x - cornors[3].x));
    }

    circle(imgToDraw, center, 2, Scalar(0, 0, 255),-1);
    line(imgToDraw, Point(imgToDraw.cols / 2, 0), Point(imgToDraw.cols / 2, imgToDraw.rows), Scalar(0, 0, 0));
    line(imgToDraw, Point(0, imgToDraw.rows / 2), Point(imgToDraw.cols, imgToDraw.rows / 2), Scalar(0, 0, 0));
    line(imgToDraw, Point(imgToDraw.cols / 2, imgToDraw.rows / 2), center, Scalar(0, 0, 0));
    distance.x = center.x - src.cols / 2;
    distance.y = src.rows / 2 - center.y;

    distance *= scale;
    return distance;
}
