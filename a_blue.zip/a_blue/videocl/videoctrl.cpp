﻿#include "videoctrl.h"
#include <QBuffer>
videoctrl::videoctrl(QWidget *parent) : QWidget(parent)
{

    openBtn = new QPushButton;
    openBtn->setText(QString::fromLocal8Bit("打开"));
    openBtn->setFixedSize(71,31);
    connect(openBtn,SIGNAL(clicked(bool)),this,SLOT(opencamera()));

    cameraCom = new QComboBox;
    cameraCom->setFixedSize(151,31);


    scalelabel_t = new QLabel;
    scalelabel_t->setFixedSize(71,31);
    scalelabel_t->setFrameStyle(QFrame::Panel|QFrame::Sunken);

    positionLabel = new QLabel(tr("X,Y:"));
    positionLabel->setFixedSize(71,31);

    positionLabel_t = new QLabel;
    positionLabel_t->setFixedSize(71,31);
    positionLabel_t->setFrameStyle(QFrame::Panel|QFrame::Sunken);

    QGridLayout *camLayout = new QGridLayout(this);

    camLayout->addWidget(cameraCom,0,0);
    camLayout->addWidget(openBtn,0,1);
    camLayout->addWidget(positionLabel,0,2);
    camLayout->addWidget(positionLabel_t,0,3);


    showlabel = new QLabel;
    showlabel->setFixedSize(320,240);
    showlabel->setFrameStyle(QFrame::Box);
    initcamerashow();

    thread = new videocl(this);
    connect(thread,SIGNAL(ImageProcessFinished(QImage,QPoint)),this,SLOT(ShowImageFromThread(QImage,QPoint)));
    connect(this,SIGNAL(open(int)),thread,SLOT(openctrl(int)));
    connect(this,SIGNAL(close1()),thread,SLOT(closectrl()));
}
videoctrl::~videoctrl()
{
     camopened=false;
     emit close1();
     thread->terminate();
     delete thread;
}

//   摄像头名称初始化
void videoctrl::initcamerashow()
{
    QList<QCameraInfo> cameras = QCameraInfo::availableCameras();
      foreach (const QCameraInfo &cameraInfo, cameras)
      {
            cameraCom->addItem(cameraInfo.description());
      }
}
void videoctrl::opencamera()
{
    if(!camopened)
    {
     openBtn->setText(QString::fromLocal8Bit("关闭"));
     camopened=true;
     emit open(cameraCom->currentIndex());
     emit opened(true);
     thread->start();
    }
    else
    {
      openBtn->setText(QString::fromLocal8Bit("打开"));
      camopened=false;
      emit close1();
      emit opened(false);
      thread->terminate();
      thread->wait();
    }
}

void videoctrl::ShowImageFromThread(QImage reframe,QPoint Qcenter)
{
  showlabel->setPixmap(QPixmap::fromImage(reframe));

  positionLabel_t->setText(QString("%1,%2").arg(Qcenter.x()).arg(Qcenter.y()));

  Qcenter2out=Qcenter;
 // emit getcenter(QPointF2Data(Qcenter));
}
QString videoctrl::getcenterdata()
{
    return QPointF2Data(Qcenter2out);
}

QString videoctrl::QPointF2Data(QPoint &centertemp)
{
    cv::Point errord;
    errord.x=centertemp.x();
    errord.y=centertemp.y();
    int CRC;
    QString send;

    send=send+"0A ";
    if(errord.x>=0)
        send=send+"1";
    else
        send=send+"0";
    if(errord.y>=0)
        send=send+"1";
    else
        send=send+"0";
    errord.x=abs(errord.x);
    errord.y=abs(errord.y);
   if(errord.x<16)
    send=send+" 0"+QString::number(errord.x,16);
   else
    send=send+" "+QString::number(errord.x,16);
   if(errord.y<16)
    send=send+" 0"+QString::number(errord.y,16);
   else
    send=send+" "+QString::number(errord.y,16);

    CRC=(errord.x+errord.y)%256;
    if(CRC<16)
     send=send+" 0"+QString::number(CRC,16);
    else
     send=send+" "+QString::number(CRC,16);
    send=send+" 7F";
    send=send.toUpper();
    return send;
}
