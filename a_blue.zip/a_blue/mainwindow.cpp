﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFileDialog>
#include "info_ui.h"
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    sendtime = new QTimer(this);
   connect(sendtime,SIGNAL(timeout()),this,SLOT(shouldsend()));

    Shoot1 = new shootArg("Position1",this);
    connect(Shoot1,SIGNAL(needdata(QString)),this,SLOT(ManuSend(QString)));

    Shoot2 = new shootArg("Position2",this);
    connect(Shoot2,SIGNAL(needdata(QString)),this,SLOT(ManuSend(QString)));

    Shoot3 = new shootArg("Position3",this);
    connect(Shoot3,SIGNAL(needdata(QString)),this,SLOT(ManuSend(QString)));

    Shoot4 = new shootArg("Position4",this);
    connect(Shoot4,SIGNAL(needdata(QString)),this,SLOT(ManuSend(QString)));

    Shoot5 = new shootArg("Position5",this);
    connect(Shoot5,SIGNAL(needdata(QString)),this,SLOT(ManuSend(QString)));

    Shoot6 = new shootArg("Position6",this);
    connect(Shoot6,SIGNAL(needdata(QString)),this,SLOT(ManuSend(QString)));

    Shoot7 = new shootArg("Position7",this);
    connect(Shoot7,SIGNAL(needdata(QString)),this,SLOT(ManuSend(QString)));

    ui->verticalLayout->addWidget(Shoot1);
    ui->verticalLayout->addWidget(Shoot2);
    ui->verticalLayout->addWidget(Shoot3);
    ui->verticalLayout->addWidget(Shoot4);
    ui->verticalLayout->addWidget(Shoot5);
    ui->verticalLayout->addWidget(Shoot6);
    ui->verticalLayout->addWidget(Shoot7);

    myProcess = new QProcess;
    connect(myProcess,SIGNAL(finished(int)),this,SLOT(initpos()));

    shootserial = new myThreadSerial;
    connect(shootserial,SIGNAL(opened(bool)),this,SLOT(showshootstaues(bool)));
    ui->COM1Layout->addLayout(shootserial->ComLayout,0,0);
    ui->shootgridLayout->addLayout(shootserial->ShowLayout,0,0);
    connect(shootserial,SIGNAL(closed()),this,SLOT(showshootclosed()));
    connect(shootserial,SIGNAL(RisOk(bool)),this,SLOT(shoot_ok_flag(bool)));

    motorserial = new myThreadSerial;
    connect(motorserial,SIGNAL(opened(bool)),this,SLOT(showmotorstaues(bool)));
    ui->COM2Layout->addLayout(motorserial->ComLayout,0,0);
    ui->motorgridLayout->addLayout(motorserial->ShowLayout,0,0);
    connect(motorserial,SIGNAL(closed()),this,SLOT(showmotorclosed()));
    connect(motorserial,SIGNAL(RisOk(bool)),this,SLOT(motor_ok_flag(bool)));

    connect(this,SIGNAL(toconfirm()),this,SLOT(shoot_confirm()));

    mytcpserial = new tcpserial;
    ui->wifiLayout->addWidget(mytcpserial);
    connect(mytcpserial,SIGNAL(opened(bool)),this,SLOT(tcpopened()));
    connect(mytcpserial,SIGNAL(closed()),this,SLOT(tcptoclose()));


    shootlabel = new QLabel("Shoot ready");
    motorLabel = new QLabel("Body ready");
    ui->statusBar->addPermanentWidget(shootlabel);
    ui->statusBar->addPermanentWidget(motorLabel);
    connect(mytcpserial,SIGNAL(control_WE(QString)),this,SLOT(we_control(QString)));
    ui->Page0Btn->setDisabled(true);
    ui->stackedWidget->setCurrentIndex(2);
    initpos();

}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::keyPressEvent(QKeyEvent *event)
{
    //qCritical()<<event;
    if(event->modifiers()==Qt::ControlModifier)
    {
        static int ctrlcc =0;
        switch(ctrlcc)
        {
        case 0: on_Page0Btn_clicked();break;
        case 1: on_Page1Btn_clicked();break;
        case 2: on_Page2Btn_clicked();break;
        }
        ctrlcc++;
        if(ctrlcc>=3)
        {
        ctrlcc=0;
        }
    }
    else
    {
        static int changenum=0;
        static int history=0;
      switch (event->key()) {
      case Qt::Key_1:history=changenum; changenum=1; changeorsave(history,changenum);break;
      case Qt::Key_2:history=changenum; changenum=2; changeorsave(history,changenum);break;
      case Qt::Key_3:history=changenum; changenum=3; changeorsave(history,changenum);break;
      case Qt::Key_4:history=changenum; changenum=4; changeorsave(history,changenum);break;
      case Qt::Key_5:history=changenum; changenum=5; changeorsave(history,changenum);break;
      case Qt::Key_6:history=changenum; changenum=6; changeorsave(history,changenum);break;
      case Qt::Key_7:history=changenum; changenum=7; changeorsave(history,changenum);break;


        case Qt::Key_Q: changedata(changenum,1,true);break;
        case Qt::Key_A: changedata(changenum,1,false);break;
        case Qt::Key_W: changedata(changenum,2,true);break;
        case Qt::Key_S: changedata(changenum,2,false);break;
        case Qt::Key_E: changedata(changenum,3,true);break;
        case Qt::Key_D: changedata(changenum,3,false);break;
        case Qt::Key_R: changedata(changenum,4,true);break;
        case Qt::Key_F: changedata(changenum,4,false);break;
        default:break;
      }

    }

}
void MainWindow::changeorsave(int H, int N)
{
    switch (H) {
        case 1: Shoot1->chgOsv();break;
        case 2: Shoot2->chgOsv();break;
        case 3: Shoot3->chgOsv();break;
        case 4: Shoot4->chgOsv();break;
        case 5: Shoot5->chgOsv();break;
        case 6: Shoot6->chgOsv();break;
        case 7: Shoot7->chgOsv();break;
    default:
        break;
    }
    switch (N) {
        case 1: Shoot1->chgOsv();break;
        case 2: Shoot2->chgOsv();break;
        case 3: Shoot3->chgOsv();break;
        case 4: Shoot4->chgOsv();break;
        case 5: Shoot5->chgOsv();break;
        case 6: Shoot6->chgOsv();break;
        case 7: Shoot7->chgOsv();break;
    default:
        break;
    }
}

void MainWindow::changedata(int num, int dataindex, bool AoS)
{
  switch (num) {
    case 1:switch (dataindex) {
                case 1:Shoot1->AoSM1(AoS);break;
                case 2:Shoot1->AoSM2(AoS);break;
                case 3:Shoot1->AoSAn(AoS);break;
                case 4:Shoot1->AoSVA(AoS);break;
                default: break;}break;
    case 2:switch (dataindex) {
              case 1:Shoot2->AoSM1(AoS);break;
              case 2:Shoot2->AoSM2(AoS);break;
              case 3:Shoot2->AoSAn(AoS);break;
              case 4:Shoot2->AoSVA(AoS);break;
              default: break;}break;
    case 3:switch (dataindex) {
              case 1:Shoot3->AoSM1(AoS);break;
              case 2:Shoot3->AoSM2(AoS);break;
              case 3:Shoot3->AoSAn(AoS);break;
              case 4:Shoot3->AoSVA(AoS);break;
              default: break;}break;
    case 4:switch (dataindex) {
              case 1:Shoot4->AoSM1(AoS);break;
              case 2:Shoot4->AoSM2(AoS);break;
              case 3:Shoot4->AoSAn(AoS);break;
              case 4:Shoot4->AoSVA(AoS);break;
              default: break;}break;
    case 5:switch (dataindex) {
              case 1:Shoot5->AoSM1(AoS);break;
              case 2:Shoot5->AoSM2(AoS);break;
              case 3:Shoot5->AoSAn(AoS);break;
              case 4:Shoot5->AoSVA(AoS);break;
              default: break;}break;
   case 6:switch (dataindex) {
             case 1:Shoot6->AoSM1(AoS);break;
             case 2:Shoot6->AoSM2(AoS);break;
             case 3:Shoot6->AoSAn(AoS);break;
             case 4:Shoot6->AoSVA(AoS);break;
             default: break;}break;
   case 7:switch (dataindex) {
             case 1:Shoot7->AoSM1(AoS);break;
             case 2:Shoot7->AoSM2(AoS);break;
             case 3:Shoot7->AoSAn(AoS);break;
             case 4:Shoot7->AoSVA(AoS);break;
             default: break;}break;
    default:
        break;
    }
}
void MainWindow::initpos()
{
  /*  QDir *dir=new QDir(QDir::currentPath());
    QStringList filter;
    filter<<"*.ini";
    dir->setNameFilters(filter);
    QList<QFileInfo> *fileInfo=new QList<QFileInfo>(dir->entryInfoList(filter));
    for(int i=0;i<fileInfo->count();i++)
     {
        ui->planBox->addItem(fileInfo->at(i).fileName());
     }*/
    QSettings *configIniRead = new QSettings("Bluevalue.ini", QSettings::IniFormat);
    if(!configIniRead->contains("COMSLOT/C1"))
    {
      configIniRead->setValue("/COMSLOT/C1", "COM9");
      configIniRead->setValue("/COMSLOT/C2", "COM8");
      configIniRead->setValue("/COMSLOT/C3", "COM7");
    }
    shootserial->setCurrentSerial(configIniRead->value("/COMSLOT/C2").toString());
    motorserial->setCurrentSerial(configIniRead->value("/COMSLOT/C3").toString());
    mytcpserial->setCurrentSerial(configIniRead->value("/COMSLOT/C1").toString());

    ui->COMList->clear();
    ui->COMList->addItem(configIniRead->value("/COMSLOT/C1").toString());
    ui->COMList->addItem(configIniRead->value("/COMSLOT/C2").toString());
    ui->COMList->addItem(configIniRead->value("/COMSLOT/C3").toString());

    delete configIniRead;
}

void MainWindow::tcpopened()
{
   //connect(motorserial,SIGNAL(showdataout(QString)),this,SLOT(tcptosend(QString)));
}

void MainWindow::tcptoclose()
{
  //  disconnect(motorserial,SIGNAL(showdataout(QString)),this,SLOT(tcptosend(QString)));
}

void MainWindow::tcptosend(QString datatemp)
{
    mytcpserial->QStringsend(datatemp);
}

void MainWindow::ManuSend(QString data)
{
   shootserial->send(data);
}
void MainWindow::shoot_ok_flag(bool flag)
{
    shootON=flag;
    emit toconfirm();
}
void MainWindow::motor_ok_flag(bool flag)
{
    motorON=flag;
    emit toconfirm();
}
void MainWindow::shoot_confirm()
{
    if(motorON==true)
    {
       // shootserial->send("0A 02 7F");
        motorON=false;
    }
}
void MainWindow::showshootstaues(bool serialstatus)
{
    if(serialstatus)
    {
        shootlabel->setText(shootserial->currentserial()+" open succed");
    }
    else
    {
         shootlabel->setText(shootserial->currentserial()+" open failed");
    }
}
void MainWindow::showshootclosed()
{
   shootlabel->setText("Shoot ready");
   ui->statusBar->showMessage(shootserial->currentserial()+"CLOSED",1000);
}
void MainWindow::showmotorstaues(bool serialstatus)
{
    if(serialstatus)
    {
        motorLabel->setText(motorserial->currentserial()+" open succed");
    }
    else
    {
         motorLabel->setText(motorserial->currentserial()+" open failed");
    }
}
void MainWindow::showmotorclosed()
{
   motorLabel->setText("Motor ready");
   ui->statusBar->showMessage(shootserial->currentserial()+"CLOSED",1000);
}
void MainWindow::sendmotorpos(int num,int shootArg)
{

    QByteArray sendtemp;
    sendtemp.resize(5);
    qint16 shootArgtemp=shootArg;

    shootArgtemp=(1800+shootArgtemp);

    sendtemp[0] = 0x0A;
    sendtemp[1] = 0x02;
    sendtemp[2] =qint8(num);
    sendtemp[3] =qint8(num);
    sendtemp[4] =qint8(shootArgtemp>>8);
    sendtemp[5] =qint8(shootArgtemp);

    sendtemp[6] =0x7F;

   motorserial->QCharsend(sendtemp);
}


void MainWindow::on_shootBtn_clicked()
{
    shootserial->send("0A 02 7F");
}
void MainWindow::shouldsend()
{
    cansend=true;
    sendtime->stop();
}

void MainWindow::we_control(QString getcontrolkey)
{
    char temp=getcontrolkey.toLatin1().at(0);

    if(getcontrolkey.contains("Q"))
    {
       ui->YGLabel->setStyleSheet("QLabel { background-color: rgb(255, 0, 0); border-radius: 3px; color: rgb(255, 255, 255); }");
        int Cotl_X=128-getcontrolkey.mid(1,getcontrolkey.indexOf("S")-1).toInt();
        int Cotl_Y=getcontrolkey.mid(getcontrolkey.indexOf("S")+1).toInt()-128;
        if(Cotl_X>10&&Cotl_Y+Cotl_X>10)
         motorserial->send("0A 02 0C 0C 07 08 7F");
        else if(Cotl_X<-10&&Cotl_Y+Cotl_X<-10)
          motorserial->send("0A 02 0D 0D 07 08 7F");
        else if(Cotl_Y<-10&&Cotl_Y+Cotl_X<-10)
          motorserial->send("0A 02 0E 0E 07 08 7F");
        else if(Cotl_Y>10&&Cotl_Y+Cotl_X>10)
          motorserial->send("0A 02 0F 0F 07 08 7F");


    }
    else
   {
    if(!sendtime->isActive())
    {
        sendtime->start(300);
    }
    if(cansend)
    {
     ui->YGLabel->setStyleSheet("QLabel { background-color: rgb(0, 255, 0); border-radius: 3px; color: rgb(255, 255, 255); }");
     switch (temp) {

     case 'A':on_PosBtn_P7_clicked(); break;
     case 'B':on_PosBtn_P1_clicked(); break;

     case 'C':on_PosBtn_P2_clicked(); break;
     case 'D':on_PosBtn_P6_clicked(); break;

     case 'I':on_PosBtn_P4_clicked(); break;
     case 'L':on_PosBtn_P5_clicked(); break;
     case 'K':on_PosBtn_P3_clicked(); break;

     case 'J':motorserial->send("0A 02 AA AA 07 08 7F");break;

     case 'G':on_PosBtn_E_clicked(); break;
     case 'H':on_PosBtn_S_clicked();break;

     case 'E':on_shootBtn_clicked(); break;
     case 'F':shootserial->send("0A 02 7F");break;

     case 'M':PosBtn_M_clicked();break;
     case 'N':clearBtn=true;break;

     default: break;
     }
     cansend=false;
    }
   }
}

void MainWindow::PosBtn_M_clicked()
{
    static int num=1;

    if(clearBtn)
    {
        num=1;
    }
    switch (num) {
    case 1:
        on_PosBtn_E_clicked();
        break;
    case 2:
        on_PosBtn_P6_clicked();
        break;
    case 3:
        on_PosBtn_P5_clicked();
        break;
    case 4:
        on_PosBtn_P4_clicked();
        break;
    case 5:
        on_PosBtn_P7_clicked();
        break;
    case 6:
        on_PosBtn_P1_clicked();
        break;
    case 7:
        on_PosBtn_P3_clicked();
        break;
    case 8:
        on_PosBtn_P2_clicked();
        break;
    default:
        break;
    }
    clearBtn=false;
    num++;
    if(num==9)
    {
        num=1;
    }
}

void MainWindow::on_PosBtn_P1_clicked()
{
    Shoot1->senddata();
    sendmotorpos(1,Shoot1->getAngleint());
}

void MainWindow::on_PosBtn_P2_clicked()
{
    Shoot2->senddata();
    sendmotorpos(2,Shoot2->getAngleint());
}

void MainWindow::on_PosBtn_P3_clicked()
{
    Shoot3->senddata();
    sendmotorpos(3,Shoot3->getAngleint());
}

void MainWindow::on_PosBtn_P4_clicked()
{
    Shoot4->senddata();
    sendmotorpos(4,Shoot4->getAngleint());
}

void MainWindow::on_PosBtn_P5_clicked()
{
    Shoot5->senddata();
    sendmotorpos(5,Shoot5->getAngleint());
}

void MainWindow::on_PosBtn_P6_clicked()
{
    Shoot6->senddata();
    sendmotorpos(6,Shoot6->getAngleint());
}

void MainWindow::on_PosBtn_P7_clicked()
{
    Shoot7->senddata();
    sendmotorpos(7,Shoot7->getAngleint());
}

void MainWindow::on_PosBtn_S_clicked()
{
   motorserial->send("0A 02 00 00 07 08 7F");
   shootserial->send("0A 01 11 11 00 00 00 00 00 00 00 7F");
}

void MainWindow::on_PosBtn_E_clicked()
{
  motorserial->send("0A 02 08 08 07 08 7F");
  shootserial->send("0A 01 11 11 00 00 00 00 00 00 00 7F");
}
void MainWindow::on_OnStartBtn_clicked()
{
    shootserial->open();
    motorserial->open();
    mytcpserial->open();
}

void MainWindow::on_COMList_doubleClicked(const QModelIndex &)
{

    QString program = "notepad.exe";
    QStringList arguments;
    arguments << "Bluevalue.ini";

    myProcess->start(program, arguments);

}

void MainWindow::on_Page0Btn_clicked()
{
     ui->stackedWidget->setCurrentIndex(0);
     ui->Page0Btn->setDisabled(true);
     ui->Page1Btn->setDisabled(false);
     ui->Page2Btn->setDisabled(false);
}

void MainWindow::on_Page1Btn_clicked()
{
     ui->stackedWidget->setCurrentIndex(1);
     ui->Page0Btn->setDisabled(false);
     ui->Page1Btn->setDisabled(true);
     ui->Page2Btn->setDisabled(false);
}

void MainWindow::on_Page2Btn_clicked()
{
     ui->stackedWidget->setCurrentIndex(2);
     ui->Page0Btn->setDisabled(false);
     ui->Page1Btn->setDisabled(false);
     ui->Page2Btn->setDisabled(true);
}

void MainWindow::on_InfoBtn_clicked()
{
    INFO_ui *P = new INFO_ui(this);
    P->setWindowTitle("Update Info");
    P->exec();
}
