#include "info_ui.h"
#include "ui_info_ui.h"

INFO_ui::INFO_ui(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::INFO_ui)
{
    ui->setupUi(this);

}

INFO_ui::~INFO_ui()
{
    delete ui;
}
