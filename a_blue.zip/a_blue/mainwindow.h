﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "shootTab/shootarg.h"
#include <QDebug>
#include "QThreadserial/mythreadserial.h"
//#include "videocl/videoctrl.h"
#include "QThreadserial/tcpserial.h"
#include <QProcess>
#include <QTimer>
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    void keyPressEvent(QKeyEvent *);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
    shootArg  *Shoot1;
    shootArg  *Shoot2;
    shootArg  *Shoot3;
    shootArg  *Shoot4;
    shootArg  *Shoot5;
    shootArg  *Shoot6;
    shootArg  *Shoot7;
    myThreadSerial *shootserial;
    myThreadSerial *motorserial;
    tcpserial      *mytcpserial;

    QProcess *myProcess;

    bool Issendflag=false;
    bool shootON=false;
    bool motorON=false;
    bool cansend=true;

    bool clearBtn=false;
    QLabel *shootlabel;
    QLabel *motorLabel;

    QTimer *sendtime;

    QTimer *sendshoottimer;

signals:
    void toconfirm();
    void todisconnect();
private slots:
    void ManuSend(QString data);
    void showshootstaues(bool serialstatus);
    void showshootclosed();
    void showmotorstaues(bool serialstatus);
    void showmotorclosed();

    void on_shootBtn_clicked();
    void tcpopened();

    void shoot_ok_flag(bool);
    void motor_ok_flag(bool);

    void shoot_confirm();

    void tcptosend(QString datatemp);
    void tcptoclose();
    void sendmotorpos(int num,int shootangle);
    void on_PosBtn_P1_clicked();
    void on_PosBtn_P2_clicked();
    void on_PosBtn_P3_clicked();
    void on_PosBtn_P4_clicked();
    void on_PosBtn_P5_clicked();
    void on_PosBtn_P6_clicked();
    void on_PosBtn_P7_clicked();
    void on_PosBtn_S_clicked();
    void on_PosBtn_E_clicked();

    void initpos();

    void shouldsend();

    void we_control(QString getcontrolkey);
    void on_OnStartBtn_clicked();
    void on_COMList_doubleClicked(const QModelIndex &index);
    void on_Page0Btn_clicked();
    void on_Page1Btn_clicked();
    void on_Page2Btn_clicked();
    void on_InfoBtn_clicked();

    void PosBtn_M_clicked();

    void changedata(int num,int dataindex,bool AoS);
    void changeorsave(int H,int N);
   // void timertoshoot();
};
#endif // MAINWINDOW_H
