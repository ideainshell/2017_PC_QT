#ifndef INFO_UI_H
#define INFO_UI_H

#include <QDialog>

namespace Ui {
class INFO_ui;
}

class INFO_ui : public QDialog
{
    Q_OBJECT

public:
    explicit INFO_ui(QWidget *parent = 0);
    ~INFO_ui();

private:
    Ui::INFO_ui *ui;
};

#endif // INFO_UI_H
