﻿#include "shootarg.h"
#include <QDebug>
shootArg::shootArg(const QString &groupname,QWidget *parent): QWidget(parent)
{
    createtemp=groupname;
    creatAll();
    ArgGroupBox->setTitle(createtemp);
    initdata(createtemp);
}
shootArg::~shootArg()
{
}

void shootArg::creatAll()
{
    ArgGroupBox = new QGroupBox;
    ArgGroupBox->setFixedSize(488,61);

    Motor1SpinBox = new QSpinBox;
    Motor1SpinBox->setFixedSize(66,31);
    Motor1SpinBox->setDisabled(true);
    Motor1SpinBox->setMaximum(7000);
    Motor1SpinBox->setMinimum(-7000);
    Motor1SpinBox->setSingleStep(50);

    Motor2SpinBox = new QSpinBox;
    Motor2SpinBox->setFixedSize(66,31);
    Motor2SpinBox->setDisabled(true);
    Motor2SpinBox->setMaximum(7000);
    Motor2SpinBox->setMinimum(-7000);
    Motor2SpinBox->setSingleStep(50);

    AngleSpinBox = new QDoubleSpinBox;
    AngleSpinBox->setFixedSize(71,31);
    AngleSpinBox->setDisabled(true);
    AngleSpinBox->setMaximum(180);
    AngleSpinBox->setMinimum(-180);
    AngleSpinBox->setSingleStep(1);

    VangleSpinBox = new QDoubleSpinBox;
    VangleSpinBox->setFixedSize(66,31);
    VangleSpinBox->setDisabled(true);
    VangleSpinBox->setMaximum(110);
    VangleSpinBox->setMinimum(-110);
    VangleSpinBox->setSingleStep(1);

    changeBtn = new QPushButton;
    changeBtn->setFixedSize(91,31);
    changeBtn->setText(QString::fromLocal8Bit("修改"));
    connect(changeBtn,SIGNAL(clicked(bool)),this,SLOT(chgOsv()));

    sendBtn = new QPushButton;
    sendBtn->setFixedSize(91,31);
    sendBtn->setText(QString::fromLocal8Bit("发送"));
    connect(sendBtn,SIGNAL(clicked(bool)),this,SLOT(senddata()));

    QHBoxLayout *Hbox = new QHBoxLayout;

    Hbox->addWidget(Motor1SpinBox);
    Hbox->addWidget(Motor2SpinBox);
    Hbox->addWidget(AngleSpinBox);
    Hbox->addWidget(VangleSpinBox);
    Hbox->addWidget(changeBtn);
    Hbox->addWidget(sendBtn);

    ArgGroupBox->setLayout(Hbox);

    QGridLayout *GBox = new QGridLayout(this);

    GBox->addWidget(ArgGroupBox);
}

void shootArg::initdata(const QString &fname)
{
    QSettings *configIniRead = new QSettings("Bluevalue.ini", QSettings::IniFormat);
    QString motor1 = configIniRead->value("/"+fname+"/M1").toString();
    QString motor2 = configIniRead->value("/"+fname+"/M2").toString();
    QString angle  = configIniRead->value("/"+fname+"/An").toString();
    QString Vangle = configIniRead->value("/"+fname+"/Va").toString();
    delete configIniRead;

    Motor1SpinBox->setValue(motor1.toInt());
    Motor2SpinBox->setValue(motor2.toInt());
    AngleSpinBox->setValue(angle.toDouble());
    VangleSpinBox->setValue(Vangle.toDouble());

}
void shootArg::chgOsv()
{
    if(CSflag==true)
    {
     Motor1SpinBox->setDisabled(false);
     Motor2SpinBox->setDisabled(false);
     AngleSpinBox->setDisabled(false);
     VangleSpinBox->setDisabled(false);

     changeBtn->setText(QString::fromLocal8Bit("保存"));
     CSflag=false;
    }
    else
    {
     Motor1SpinBox->setDisabled(true);
     Motor2SpinBox->setDisabled(true);
     AngleSpinBox->setDisabled(true);
     VangleSpinBox->setDisabled(true);

     QSettings *configIniWrite = new QSettings("Bluevalue.ini", QSettings::IniFormat);
     configIniWrite->setValue("/"+createtemp+"/M1", Motor1SpinBox->text());
     configIniWrite->setValue("/"+createtemp+"/M2", Motor2SpinBox->text());
     configIniWrite->setValue("/"+createtemp+"/An", AngleSpinBox->text());
     configIniWrite->setValue("/"+createtemp+"/Va", VangleSpinBox->text());
     delete configIniWrite;

     changeBtn->setText(QString::fromLocal8Bit("修改"));
     CSflag=true;
    }
}
QString shootArg::Argdata()
{
    return Motor1SpinBox->text()+" "+Motor2SpinBox->text()+" "+AngleSpinBox->text()+" "+VangleSpinBox->text();
}
int shootArg::getAngleint()//给底盘的
{
    return AngleSpinBox->text().toDouble()*10;
}

QString shootArg::getAngle()//未用
{
    QString formatAngle;
    double ang;
    quint8 data[2];
    ang=AngleSpinBox->text().toDouble()+180;

    ang=ang*10;
    data[0]=(int)ang/256;
    data[1]=(int)ang%256;

    for(int i=0;i<2;i++)
    {
     if(data[i]<16)
      formatAngle=formatAngle+" 0"+QString::number(data[i],16);
     else
      formatAngle=formatAngle+" "+QString::number(data[i],16);
    }
    return formatAngle.toUpper();


}
void shootArg::senddata()
{
    QString temp;
   temp=formatdata(Motor1SpinBox->value(),Motor2SpinBox->value(),VangleSpinBox->value());
   emit needdata(temp);
}
QString shootArg::formatdata(int motor1,int motor2,double angle)//这个小路
{
    QString send;
    quint8 data[7];

    send=send+"0A 01 ";
    if(motor1>=0)
        send=send+"1";
    else
        send=send+"0";
    if(motor2>=0)
        send=send+"1";
    else
        send=send+"0";

    if(angle>=0)
        send=send+" 11";
    else
        send=send+" 00";

    motor1=abs(motor1);
    motor2=abs(motor2);
    angle =abs(angle);

    data[0]=motor1/256;
    data[1]=motor1%256;

    data[2]=motor2/256;
    data[3]=motor2%256;

    angle=angle*10;
    data[4]=(int)angle/256;
    data[5]=(int)angle%256;

    data[6]=(data[0]+data[1]+data[2]+data[3]+data[4]+data[5])%256;
   for(int i=0;i<7;i++)
   {
    if(data[i]<16)
     send=send+" 0"+QString::number(data[i],16);
    else
     send=send+" "+QString::number(data[i],16);
   }

    send=send+" 7F";
    send=send.toUpper();
    return send;

}
void shootArg::disablesendBtn(bool Issend)
{
    sendBtn->setDisabled(Issend);
}

void shootArg::AoSM1(bool IsA)
{
   if(Motor1SpinBox->isEnabled())
    if(IsA)
    {
        Motor1SpinBox->setValue(Motor1SpinBox->value()+10);
    }
    else
    {
        Motor1SpinBox->setValue(Motor1SpinBox->value()-10);
    }
}
void shootArg::AoSM2(bool IsA)
{
    if(Motor2SpinBox->isEnabled())
     if(IsA)
     {
         Motor2SpinBox->setValue(Motor2SpinBox->value()+10);
     }
     else
     {
         Motor2SpinBox->setValue(Motor2SpinBox->value()-10);
     }
}
void shootArg::AoSAn(bool IsA)
{
    if(AngleSpinBox->isEnabled())
     if(IsA)
     {
         AngleSpinBox->setValue(AngleSpinBox->value()+1);
     }
     else
     {
         AngleSpinBox->setValue(AngleSpinBox->value()-1);
     }

}
void shootArg::AoSVA(bool IsA)
{
    if(VangleSpinBox->isEnabled())
     if(IsA)
     {
         VangleSpinBox->setValue(VangleSpinBox->value()+1);
     }
     else
     {
         VangleSpinBox->setValue(VangleSpinBox->value()-1);
     }
}
